-The exact location of each soil pressure cell can be found in the "SensorArrangement.pdf" file.
-All displacement levels are positive numbers (soil pressure data is recorded in the push direction).
-In the text files, "N/A" indicates that the experimental data is not applicable.

